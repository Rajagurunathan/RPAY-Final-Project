import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-airtel',
  templateUrl: './airtel.component.html',
  styleUrls: ['./airtel.component.css']
})
export class AirtelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
