import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vi',
  templateUrl: './vi.component.html',
  styleUrls: ['./vi.component.css']
})
export class ViComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
