import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bsnl',
  templateUrl: './bsnl.component.html',
  styleUrls: ['./bsnl.component.css']
  
})
export class BsnlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
