export class OperatorFinder
{
    status:string;
    error:string;
    operator_code:string;
    operator_name:string;
    circle_code:string;
    circle_name:string;
    current_type:string;
    hits_left: number
}