
export class rechargestatus {
    status: string;
    error: string;
    txid: string;
    operator: string;
    service: string;
    amount: string;
    orderid: string;
    operatorid: string;
    balance: string;
    margin: string;
    time: string;
    duration: string;
  }
  