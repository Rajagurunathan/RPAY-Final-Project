export class WalletHistory
{
    transactionid: string;
        username: string;
        transaction_time: string;
        amount: number;
        credit: string;
        debit: string;
        status: string;
}