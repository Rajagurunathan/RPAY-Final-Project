export interface User
{
    userName:string;
    fullName:string;
    email:string;
}